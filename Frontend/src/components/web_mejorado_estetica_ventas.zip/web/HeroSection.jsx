import { motion } from "framer-motion";
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  CheckCircle2,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import logoMark from "../../imagenes/balto.png";
import logoBaltoAzul from "../../imagenes/Logo_Balto_Azul.png";

const TITULO = "Centralizá ventas, compras y reportes en un solo sistema.";
const SUBTITULO =
  "Balto ordena tu gestión diaria con módulos claros, reportes útiles y una experiencia rápida para equipos que necesitan control real sin sumar complejidad.";

const HIGHLIGHTS = [
  { icon: BadgeCheck, text: "Implementación simple" },
  { icon: BarChart3, text: "Reportes en tiempo real" },
  { icon: ShieldCheck, text: "Datos organizados y seguros" },
];

const METRICS = [
  { label: "Ventas", value: "+18%" },
  { label: "Egresos", value: "-$42k" },
  { label: "Resultado", value: "+$128k" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 34 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.75,
      ease: [0.22, 1, 0.36, 1],
    },
  },
};

export function HeroSection() {
  return (
    <section
      id="inicio"
      className="relative isolate flex min-h-[100svh] overflow-hidden bg-[#f7f9fc] pt-28 pb-16 sm:pt-32 lg:pt-28"
    >
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(0,85,187,0.13),transparent_34%),radial-gradient(circle_at_bottom_right,rgba(10,37,64,0.08),transparent_36%)]" />
        <div className="absolute left-[-6rem] top-0 h-72 w-72 rounded-full bg-[rgba(0,85,187,0.12)] blur-[120px] sm:h-96 sm:w-96 sm:blur-[130px]" />
        <div className="absolute right-[-4rem] top-28 h-64 w-64 rounded-full bg-[rgba(10,37,64,0.09)] blur-[115px] sm:h-80 sm:w-80 sm:blur-[125px]" />
        <div className="absolute inset-0 opacity-[0.04] [background-image:linear-gradient(rgba(10,37,64,0.55)_1px,transparent_1px),linear-gradient(90deg,rgba(10,37,64,0.55)_1px,transparent_1px)] [background-size:44px_44px]" />
        <img
          src={logoMark}
          alt=""
          aria-hidden="true"
          className="absolute left-1/2 top-1/2 hidden h-[460px] w-[460px] -translate-x-1/2 -translate-y-1/2 object-contain opacity-[0.018] lg:block"
        />
      </div>

      <div className="relative mx-auto flex w-full max-w-7xl items-center px-4 sm:px-6 lg:px-8">
        <div className="grid w-full items-center gap-12 lg:grid-cols-[1.02fr_0.98fr] lg:gap-16">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="visible"
            className="text-center lg:text-left"
          >
            <div className="mx-auto inline-flex items-center gap-2 rounded-full border border-[rgba(0,85,187,0.14)] bg-white/75 px-4 py-2 text-[13px] font-medium text-[var(--balto-midnight)] shadow-[0_14px_35px_rgba(10,37,64,0.07)] backdrop-blur-xl lg:mx-0">
              <Sparkles className="h-4 w-4 text-[var(--balto-action)]" />
              Gestión contable moderna para empresas y estudios
            </div>

            <h1 className="mx-auto mt-7 max-w-4xl text-4xl font-semibold tracking-[-0.05em] text-[var(--balto-midnight)] sm:text-5xl lg:mx-0 lg:text-6xl">
              {TITULO}
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-base leading-8 text-[var(--balto-muted)] sm:text-lg lg:mx-0">
              {SUBTITULO}
            </p>

            <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row lg:justify-start">
              <a
                href="#pricing"
                className="group inline-flex items-center justify-center gap-2 rounded-2xl bg-[var(--balto-action)] px-6 py-3.5 text-sm font-medium text-white shadow-[0_18px_42px_rgba(0,85,187,0.28)] transition duration-300 hover:-translate-y-0.5 hover:shadow-[0_22px_55px_rgba(0,85,187,0.34)]"
              >
                Ver planes
                <ArrowRight className="h-4 w-4 transition duration-300 group-hover:translate-x-0.5" />
              </a>

              <a
                href="#features"
                className="inline-flex items-center justify-center rounded-2xl border border-slate-200/80 bg-white/75 px-6 py-3.5 text-sm font-medium text-[var(--balto-midnight)] shadow-[0_14px_35px_rgba(10,37,64,0.07)] backdrop-blur-xl transition duration-300 hover:-translate-y-0.5 hover:border-[rgba(0,85,187,0.22)] hover:text-[var(--balto-action)]"
              >
                Explorar beneficios
              </a>
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              {HIGHLIGHTS.map(({ icon: Icon, text }) => (
                <div
                  key={text}
                  className="flex items-center justify-center gap-2 rounded-2xl border border-white/80 bg-white/70 px-4 py-3 text-sm font-medium text-slate-700 shadow-[0_14px_34px_rgba(10,37,64,0.06)] backdrop-blur-xl lg:justify-start"
                >
                  <Icon className="h-4 w-4 shrink-0 text-[var(--balto-action)]" />
                  <span>{text}</span>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            variants={fadeUp}
            initial="hidden"
            animate="visible"
            className="relative"
          >
            <div className="absolute -inset-4 rounded-[42px] bg-[linear-gradient(135deg,rgba(0,85,187,0.16),rgba(255,255,255,0.65),rgba(10,37,64,0.08))] blur-2xl" />

            <div className="relative overflow-hidden rounded-[34px] border border-white/85 bg-white/82 p-5 shadow-[0_30px_90px_rgba(10,37,64,0.14)] backdrop-blur-2xl sm:p-7">
              <div className="pointer-events-none absolute -right-20 -top-20 h-52 w-52 rounded-full bg-[rgba(0,85,187,0.12)] blur-3xl" />
              <div className="pointer-events-none absolute -bottom-24 left-10 h-56 w-56 rounded-full bg-[rgba(10,37,64,0.08)] blur-3xl" />

              <div className="relative flex items-center justify-between gap-4 border-b border-slate-100 pb-5">
                <img
                  src={logoBaltoAzul}
                  alt="Balto Sistema Contable"
                  className="h-auto w-36 object-contain sm:w-44"
                />

                <span className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700 ring-1 ring-emerald-100">
                  <span className="h-2 w-2 rounded-full bg-emerald-500" />
                  Activo
                </span>
              </div>

              <div className="relative mt-6 grid gap-3 sm:grid-cols-3">
                {METRICS.map((item) => (
                  <div
                    key={item.label}
                    className="rounded-2xl border border-slate-100 bg-white/80 p-4 shadow-[0_12px_28px_rgba(10,37,64,0.06)]"
                  >
                    <p className="text-xs font-medium uppercase tracking-[0.16em] text-slate-400">
                      {item.label}
                    </p>
                    <p className="mt-2 text-xl font-semibold tracking-tight text-[var(--balto-midnight)]">
                      {item.value}
                    </p>
                  </div>
                ))}
              </div>

              <div className="relative mt-5 rounded-[26px] border border-slate-100 bg-[#f8fbff] p-5">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-[var(--balto-midnight)]">
                      Resumen del mes
                    </p>
                    <p className="mt-1 text-sm text-[var(--balto-muted)]">
                      Indicadores claros para decidir mejor.
                    </p>
                  </div>
                  <BarChart3 className="h-6 w-6 text-[var(--balto-action)]" />
                </div>

                <div className="mt-5 space-y-3">
                  {[78, 58, 42].map((width, index) => (
                    <div key={index} className="h-3 overflow-hidden rounded-full bg-white shadow-inner">
                      <div
                        className="h-full rounded-full bg-[linear-gradient(90deg,var(--balto-action),#2f7ee8)]"
                        style={{ width: `${width}%` }}
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative mt-5 flex items-center gap-3 rounded-2xl border border-[rgba(0,85,187,0.10)] bg-[rgba(0,85,187,0.06)] px-4 py-3 text-sm text-[var(--balto-midnight)]">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-[var(--balto-action)]" />
                Controlá ventas, compras, clientes y reportes desde una sola plataforma.
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
