import { motion } from "framer-motion";
import { MessageSquareQuote, Star, Quote } from "lucide-react";
import logoMark from "../../imagenes/balto.png";

const BADGE = "Opiniones";
const TITLE = "Equipos que ya trabajan con más claridad.";
const DESCRIPTION =
  "Una propuesta pensada para simplificar la operación real, no para sumar complejidad.";

const TESTIMONIALS = [
  {
    id: 1,
    name: "Laura Gómez",
    role: "Contadora",
    quote:
      "Balto nos permitió ordenar la operación de varios clientes desde un único lugar. La curva de aprendizaje es casi nula.",
  },
  {
    id: 2,
    name: "Martín Ríos",
    role: "Dueño de PyME",
    quote:
      "Antes perdíamos horas buscando datos entre planillas. Ahora todo está en un sistema y los reportes salen solos.",
  },
  {
    id: 3,
    name: "Sofía Herrera",
    role: "Administradora",
    quote:
      "Lo que más valoro es la claridad de la interfaz. Cualquier persona del equipo puede usarlo sin capacitación especial.",
  },
];

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12 } },
};

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] },
  },
};

function getInitials(name = "C") {
  return String(name)
    .trim()
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0]?.toUpperCase() || "")
    .join("");
}

function StarsRow() {
  return (
    <div className="flex items-center gap-1">
      {[...Array(5)].map((_, index) => (
        <Star
          key={index}
          className="h-4 w-4 fill-[var(--balto-action)] text-[var(--balto-action)]"
        />
      ))}
    </div>
  );
}

export function TestimonialsSection() {
  return (
    <section
      id="testimonials"
      className="relative overflow-hidden py-20 sm:py-24"
    >
      <div className="pointer-events-none absolute inset-0">
        <img
          src={logoMark}
          alt=""
          aria-hidden="true"
          className="absolute -right-16 top-10 hidden h-72 w-72 object-contain opacity-[0.025] lg:block"
        />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          className="mx-auto max-w-2xl text-center"
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <div className="inline-flex items-center gap-2 rounded-full border border-[var(--balto-border)] bg-white px-4 py-2 shadow-sm">
            <MessageSquareQuote className="h-4 w-4 text-[var(--balto-action)]" />
            <span className="h-4 w-px bg-slate-200" />
            <img
              src={logoMark}
              alt=""
              aria-hidden="true"
              className="h-4 w-4 object-contain opacity-80"
            />
            <span className="text-sm font-medium text-[var(--balto-action)]">
              {BADGE}
            </span>
          </div>

          <h2 className="mt-4 text-3xl font-semibold tracking-tight text-[var(--balto-midnight)] sm:text-4xl">
            {TITLE}
          </h2>

          <p className="mt-4 text-base leading-7 text-[var(--balto-muted)] sm:text-lg">
            {DESCRIPTION}
          </p>
        </motion.div>

        <motion.div
          className="mt-14 grid gap-6 lg:grid-cols-3"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          {TESTIMONIALS.map((item) => (
            <motion.article
              key={item.id}
              variants={fadeUp}
              className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-[var(--balto-border)] bg-white p-7 shadow-sm transition duration-300 hover:-translate-y-1.5 hover:shadow-xl"
            >
              <img
                src={logoMark}
                alt=""
                aria-hidden="true"
                className="pointer-events-none absolute -right-7 -bottom-9 h-28 w-28 object-contain opacity-[0.025] transition duration-300 group-hover:opacity-[0.055]"
              />

              <div className="relative mb-5 flex items-center justify-between">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--balto-action)]/10">
                  <Quote className="h-5 w-5 text-[var(--balto-action)]" />
                </div>
                <StarsRow />
              </div>

              <p className="relative flex-1 text-[15px] leading-7 text-slate-700 sm:text-base">
                "{item.quote}"
              </p>

              <div className="relative mt-6 flex items-center gap-4 border-t border-slate-100 pt-5">
                <div className="relative flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-[var(--balto-midnight)] text-sm font-semibold text-white shadow-sm">
                  <img
                    src={logoMark}
                    alt=""
                    aria-hidden="true"
                    className="absolute h-8 w-8 object-contain opacity-[0.12]"
                  />
                  <span className="relative">{getInitials(item.name)}</span>
                </div>

                <div className="min-w-0">
                  <p className="truncate font-semibold text-[var(--balto-midnight)]">
                    {item.name}
                  </p>
                  <p className="truncate text-sm text-[var(--balto-muted)]">
                    {item.role}
                  </p>
                </div>
              </div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
